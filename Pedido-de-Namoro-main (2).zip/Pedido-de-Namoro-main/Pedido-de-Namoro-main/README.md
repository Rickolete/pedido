<h1>Pedido de Namoro</h1>

<p>Este projeto contém um simples pedido de namoro feito em HTML e JS, com um toque divertido. Literalmente irresistível, quando o mouse se aproxima do botão "não", ele "foge" aparecendo aleatoriamente na tela, impossibilitando clicar no "não". Se o usuário clicar no botão "Sim", ele será surpreendido com uma mensagem de congratulações</p>

https://github.com/coelhobugado/Pedido-de-Namoro/assets/56519014/030c049c-f653-453e-8bc2-08803e3a1e19


<p>Este projeto contém um simples pedido de namoro feito em HTML e JS, com um toque divertido. Ao clicar no botão "Não", ele se desloca randomicamente pela tela. Se o usuário clicar no botão "Sim", ele vai ser surpreendido com uma mensagem de congratulações.</p>

<h2>Emojis utilizados:</h2>

<ul>
  <li>🎉 (Parabéns)</li>
</ul>
